-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2024 at 03:48 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vbdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `cart` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`cart`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `phone`, `address`, `order_date`, `cart`) VALUES
(1, 'Yen Hann', '0101243456', 'hdhfgdhdhd', '2024-10-21 12:41:49', '[{\"name\":\"Volleyball Jersey\",\"price\":25,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment\\/Image\\/jerseyVolley.png\",\"quantity\":1,\"size\":\"S\"}]'),
(2, 'xx', '0109999999', 'hdhfgdhdhd', '2024-10-21 12:42:49', '[{\"name\":\"Volleyball\",\"price\":20,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment\\/Image\\/volleyBall.jpg\",\"quantity\":1,\"size\":\"\"},{\"name\":\"Volleyball Jersey\",\"price\":25,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment\\/Image\\/jerseyVolley.png\",\"quantity\":1,\"size\":\"M\"},{\"name\":\"Volleyball Shoes\",\"price\":45,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment\\/Image\\/shoe.jpg\",\"quantity\":1,\"size\":\"10\"}]'),
(3, 'Yen Hann', '0101243456', 'sdasdasd', '2024-10-21 12:51:49', '[{\"name\":\"Volleyball Jersey\",\"price\":25,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment\\/Image\\/jerseyVolley.png\",\"quantity\":1,\"size\":\"M\"}]'),
(4, 'Yen Hann', '0109999999', 'hdhfgdhdhd', '2024-10-21 12:56:17', '[{\"name\":\"Volleyball Jersey\",\"price\":25,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment\\/Image\\/jerseyVolley.png\",\"quantity\":1,\"size\":\"M\"}]'),
(5, 'William Wong Kap Onn', '0128894667', 'B607 TIARA KELANA CONDO, 1 JLN SS7/19, KELANA JAYA', '2024-10-21 14:38:33', '[{\"name\":\"Volleyball Jersey\",\"price\":25,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment%20Code\\/Images\\/jerseyVolley.png\",\"quantity\":1,\"size\":\"S\"}]'),
(6, 'William Wong Kap Onn', '0128894667', 'B607 TIARA KELANA CONDO, 1 JLN SS7/19, KELANA JAYA', '2024-10-21 14:44:34', '[{\"name\":\"Volleyball Jersey\",\"price\":25,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment%20Code\\/Images\\/jerseyVolley.png\",\"quantity\":1,\"size\":\"S\"}]'),
(7, 'William Wong Kap Onn', '0128894667', 'B607 TIARA KELANA CONDO, 1 JLN SS7/19, KELANA JAYA', '2024-10-21 21:52:46', '[{\"name\":\"Volleyball Shoes\",\"price\":45,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment%20Code\\/Images\\/shoe.jpg\",\"quantity\":1,\"size\":\"10\"}]'),
(8, 'Winston', '012-360-2708', 'B607 TIARA KELANA CONDO, 1 JLN SS7/19, KELANA JAYA', '2024-10-21 22:26:11', '[{\"name\":\"Volleyball\",\"price\":20,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Test\\/Assignment%20Code\\/Images\\/volleyBall.jpg\",\"quantity\":1,\"size\":\"\"}]'),
(9, 'daniel', '123', 'KL', '2024-10-22 10:08:50', '[{\"name\":\"Volleyball Shoes\",\"price\":45,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Presentation\\/Assignment%20Code\\/Images\\/shoe.jpg\",\"quantity\":1,\"size\":\"6\"},{\"name\":\"Volleyball\",\"price\":20,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Presentation\\/Assignment%20Code\\/Images\\/volleyBall.jpg\",\"quantity\":14,\"size\":\"\"}]'),
(10, 'Tan Yi Han', '012', 'KL', '2024-10-22 10:25:53', '[{\"name\":\"Volleyball Shoes\",\"price\":45,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Presentation\\/Assignment%20Code\\/Images\\/shoe.jpg\",\"quantity\":1,\"size\":\"9\"}]'),
(11, 'William Wong Kap Onn', '0128894667', 'B607 TIARA KELANA CONDO, 1 JLN SS7/19, KELANA JAYA', '2024-10-26 09:44:07', '[{\"name\":\"Volleyball\",\"price\":20,\"image\":\"http:\\/\\/localhost\\/RWDD2304\\/Assignment%20Code%20(3)\\/Assignment%20Code\\/Images\\/volleyBall.jpg\",\"quantity\":1,\"size\":\"\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `vbdb`
--

CREATE TABLE `vbdb` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Age` int(3) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Password` varchar(8) NOT NULL,
  `Role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vbdb`
--

INSERT INTO `vbdb` (`ID`, `Name`, `Age`, `Email`, `Address`, `Phone`, `Password`, `Role`) VALUES
(1, 'Tan Yi Han', 20, 'tp070378@gmail.com', '3, Jalan Gembira', '0124822163', '123', 'A'),
(2, 'Grey', 17, 'grey123@gmail.com', '125, Jalan Sedih 1', '0123456789', '000', 'M'),
(3, 'Bright', 20, 'tyh17330@gmail.com', '124, Jalan Gembira 2', '0123222163', '000', 'M'),
(5, 'William Wong Kap Onn', 19, 'williamteam10@gmail.com', 'B607 TIARA KELANA CONDO', '0128894667', '123456', 'M');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vbdb`
--
ALTER TABLE `vbdb`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `vbdb`
--
ALTER TABLE `vbdb`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
