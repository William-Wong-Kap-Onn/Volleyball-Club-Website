<?php 
session_start();
include('session.php');
if (!isset($_SESSION['Role']) == 'M'){
    header('Location: loginPage.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="Shortcut Icon" href="Images/SmallLogo.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box; /*This makes the div same size although one may have 50px padding and the other don't (Regardless of padding, border)*/
        }

        body {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: floralwhite;
        }

        /* Header styling */
        header {
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: bisque;
            padding: 10px 0;
            z-index: 1000; /*This makes so header is 1000 page infornt*/
        }

        nav {
            display: flex; /* example: https://www.w3schools.com/cssref/playdemo.php?filename=playcss_display&preval=flex*/
            justify-content: space-between; /* example: https://www.w3schools.com/cssref/playdemo.php?filename=playcss_display&preval=flex*/
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .logo img{
            width: 200px;
            height: auto;          
        }

        .nav-links {
            list-style: none;
            display: flex;
            position: relative;
        }

        .nav-links li {
            margin-left: 20px;
            position: relative;
        }

        .nav-links a {
            font-weight: bold;
            color: black;
            text-decoration: none;
            font-size: 10pt;
            padding: 8px 15px;
            transition: all 1s ease;
        }

        .nav-links a:hover {
            color: darkkhaki;          
        }

        .dropdown {
            position: absolute;
            top: calc(100% + 5px);
            left: 0;
            display: none;
            background-color: bisque;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            list-style: none;
            padding: 0;
            width: 120px;
            margin: 0;
            z-index: 1000
        }

        .dropdown li {
            margin: 0;
        }

        .dropdown a {
            display: block;
            padding: 5px 10px;
            font-size: 9pt;
            text-align: left;
            transition: all 1s ease;
        }

        .dropdown a:hover {
            color: darkkhaki;
        }

        /* Show the dropdown when hovering on desktop */
        .nav-links li:hover .dropdown {
            display: block;
        }

        .cta {
            display: flex;
            align-items: center;
        }

        .cta img {
            width: 17px;           
            margin-right: 2px;
        }
        
        .cta .cartbtn {
            background-color: bisque;
            padding: 8px 15px;
            color: #fff;
            display: flex;
            margin-right: 4px;
            align-items: center;
        }

        .cta .shopbtn {
            background-color: orangered;
            padding: 8px 15px;
            color: black;
            font-weight: bold;
            font-size: 9pt;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 1s ease;
        }

        .signup-btn {
            margin-bottom: 20px;
            background-color: lemonchiffon;
            color: black;
            padding: 14px 28px;
            font-size: 12pt;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }

        .session {
            margin-bottom: 20px;
            background-color: lemonchiffon;
            color: black;
            padding: 14px 28px;
            font-size: 12pt;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }

        .session a {
            font-weight: bold;
            color: black;
            text-decoration: none;
            font-size: 10pt;
            padding: 8px 15px;
            transition: all 1s ease;
        }

        main{
            padding-top: 100px;
            padding-bottom: 20px; 
            padding: 20px;
        }
       
        /* Main Section */
        .welcome {
            background-image: url(Images/hpCoverPic.png);
            background-size: cover;
            background-position: center;
            color: black;
            text-align: center;
            padding: 100px 20px;
        }

        .welcome-content h1 {
            font-size: 32pt;
            margin-bottom: 10px;
            color: saddlebrown;
        }

        .welcome-content p{
            font-size: 24pt;
            font-weight: bold;
            color: lightsalmon;
        }    

        /* Our Goal Section */
        .ourgoal {
            text-align: center;
            padding: 50px 20px;
            background-color: lavenderblush;
        }

        .ourgoal h2{
            font-size: 26pt;
            color: dimgray;
            margin-bottom: 20px;
        }

        .ourgoal p{
            font-size: 14pt;
            font-weight: bold;
            color: mediumseagreen;
        }

        .whyus{
            text-align: center;
            padding: 50px 20px;
            background-color: floralwhite;
        }

        .whyus h2{
            font-size: 26pt;
            color: slategray;
            margin-bottom: 20px;
        }

        .whyus p{
            font-size: 13pt;
            font-weight: bold;
            color: #0096FF;
        }

        /* Coaches Section */
        .coaches {
            background-color: antiquewhite;
            padding: 50px 20px;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .coaches h2 {
            font-size: 26pt;
            color: slategray;
        }

        .coach-card {
            background-color: white;
            border: 1px solid black;
            padding: 20px;
            border-radius: 8px;
            margin: 10px;
            width: 250px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            text-align: center;
        }

        .coach-card img {
            width: 200px;
            height: 200px;
            object-fit: cover;
            margin-bottom: 15px;
        }

        
        footer{
            background-color: #333;
            color: white;
            text-align: left;
            padding: 16px;
            margin-top: 20px;
            clear: both;
        }

        footer p{
            font-size: 20pt;
        }
        /* Responsive styling */
        /* Responsive Layout: Desktop and Larger Devices */
        @media (min-width: 1024px) {
            nav {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                padding: 0 15px;
            }

            .logo img {
                width: 180px; 
            }

            .nav-links li {
                margin-left: 15px; 
            }

            .nav-links a {
                font-size: 9pt; 
                padding: 8px 12px;
            }

            .cta .cartbtn {
                padding: 6px 12px;
                font-size: 9pt;
            }
        }

        /* Tablet Layout */
        @media (min-width: 768px) and (max-width: 1023px) {
            nav {
                flex-direction: column;
                align-items: flex-start;
                padding: 0 10px;
            }

            .nav-links {
                flex-direction: column;
                width: 100%;
                margin-top: 10px;
            }

            .nav-links li {
                margin: 10px 0;
            }

            .nav-links a {
                width: 100%;
                padding: 10px 0;
                text-align: center;
                font-size: 12pt;
            }

            .cta {
                margin-top: 10px;
            }
            body{
                padding-top: 360px;
            }
        }

         /*Mobile Layout*/
        @media (max-width: 767px) {
            .logo img {
                width: 150px;
            }
            
            nav {
                flex-direction: column;
                align-items: flex-start;
                padding: 10px;
            }

            .nav-links { 
                flex-direction: column;
                width: 100%;
            }

            .nav-links li {
                margin: 10px 0;
            }

            .nav-links a {
                width: 100%;
                padding: 10px;
                text-align: center;
                font-size: 12pt;
            }

            .cta {
                margin-top: 10px;
            }

            .cta .cartbtn {
                font-size: 14px;
                padding: 10px;
            }

            body{
                padding-top: 425px;
            }
        } 
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <a href="logHomepage.php">
                    <img src="Images/Logo.png" alt="Logo Icon">
                </a>
            </div>

            <ul class="nav-links">
                <li><a href="logHomepage.php">Homepage</a></li>
                <li>
                    <a href="AboutUs.html">About Us</a>
                    <ul class="dropdown">
                        <li><a href="CoachLC.html">Coach Chrollo</a></li>
                        <li><a href="CoachJS.html">Coach Smith</a></li>
                    </ul>
                </li>
                <li><a href="ContactUs.html">Contact Us</a></li>
                <li><a href="Program.html">Program</a></li>
                <li><a href="Calendar.html">Calendar</a></li>
                <li><a href="FAQ.html">FAQ</a></li>
                <li><a href="Testimonials.html">Testimonials</a></li>
            </ul>

            <div class="cta">
                <a href="shop.html" class="shopbtn">Shop</a>
                <a href="viewcart.html" class="cartbtn"><img src="Images/Cart.png" alt="Cart Icon"></a>
            </div>

            <div class="session">         
                    <a href="modifyProfile.php">EditProfile</a> | 
                    <a href="logoutPage.php">Logout</a>
            </div>
        </nav>
    </header>

    <main>    
         <!-- Hero Section -->
    <section class="welcome">
        <div class="welcome-content">
            <h1>Welcome to Tobe Volleyball Club</h1>
            <p>Start Your Volleyball Journey With Us</p>
            <a href="Program.html" class="signup-btn">Join Us Now</a>
        </div>
    </section>

    <!-- Our Goal Section -->
    <section class="ourgoal">
        <h2>Our Goal</h2>
        <p>At Tobe Volleyball Club, we strive to provide the best training and experience for youth players of all levels to enjoy playing volleyball.</p>
    </section>

    <section class="whyus">
        <h2>Why Choose Us</h2>
        <p>At Tobe Volleyball Club, we believe there that good character and attitude is the most important in each person. 
        With the right attitude, character and mindset, not only will you win tournaments – you will be set to win at life.</p>
        <br>
        <p>We welcome your child to Tobe Volleyball Club - so that we can continue to learn, grow and play an active role in shaping their futures.</p>

    </section>

    <!-- Coaches Section -->
    <section class="coaches">
        <h2>Meet Our Coaches</h2>
        <div class="coach-card">
            <a href="CoachLC.html"><img src="Images/HCoach.png" alt="Coach 1" /></a>
            <h3>Coach Chrollo</h3>
            <p>Head Coach</p>
        </div>
        <div class="coach-card">
            <a href="CoachJS.html"><img src="Images/Acoach.png" alt="Coach 2" /></a>
            <h3>Coach Smith</h3>
            <p>Assistant Coach</p>
        </div>
    </section>
    </main>

    <footer>
        <p>&copy; Tobe Volleyball Club</p>
        <div id="Footer"></div>
            <h3>CONTACT INFO</h3>
            <label>
            <table>
                <tr>
                    <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4vtphMtxRWfK6nO2CIbGfSETyEs79Dr6oPw&s" alt="Gmail Picture" 
                        height="30" width="45"></td>
                    <td>Email Address:</td>
                    <td><a href="mailto:TobeVC@gmail.com" target="_blank">TobeVC@gmail.com</a></td>
                </tr>
                <tr>
                    <td><img src="https://seeklogo.com/images/W/whatsapp-logo-0DBD89C8E2-seeklogo.com.png" alt="Whatsapp Logo"
                        height="30" width="45"></td>
                    <td>Phone Number:</td>
                    <td>
                        <a href="https://wa.me/+60128894667" target="_blank"></a>
                        <a href="tel:+60128894667" target="_blank">+60128894667</a>
                    </td>
                </tr>
            </table>
            </label>
        </div>
    </footer>

</body>
</html>