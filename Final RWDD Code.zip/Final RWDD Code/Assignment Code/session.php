<?php 
    session_start();
    if(isset($_Session['ID']))
    if(isset($_Session['Role']))
?>