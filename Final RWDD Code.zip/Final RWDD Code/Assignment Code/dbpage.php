<?php
$hostname = 'localhost'; 
$user = 'root';
$password = '';
$database  = 'vbdb';

$connection = mysqli_connect($hostname, $user, $password, $database);

if ($connection === false) {
    die('Connection failed!' . mysqli_connect_error());
}