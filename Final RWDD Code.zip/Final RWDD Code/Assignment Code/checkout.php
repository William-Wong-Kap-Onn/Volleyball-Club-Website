<?php 
include('session.php');
if ($_SESSION['Role'] !== 'M' && $_SESSION['Role'] !== 'A'){
    echo '<script type="text/javascript">
            alert("Please login first before purchasing.");
            window.location.href = "loginPage.php";
          </script>';
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="style.css"> <!-- Link to your main stylesheet -->
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: floralwhite;
            padding: 20px;
        }
        .checkout-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #fff;
        }
        h1 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: orangered;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        button:hover {
            background-color: darkorange;
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <h1>Checkout</h1>
        <form action="save_order.php" method="POST">
            <div class="form-group">
                <input type="text" name="name" placeholder="Your Name" required>
            </div>
            <div class="form-group">
                <input type="text" name="phone" placeholder="Your Phone" required>
            </div>
            <div class="form-group">
                <input type="text" name="address" placeholder="Your Address" required>
            </div>
            <input type="hidden" name="cart" id="cart" value="">
            <button type="submit">Purchase</button>
        </form>
    </div>

    <script>
        // Populate the hidden input with cart data
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        document.getElementById('cart').value = JSON.stringify(cart);
    </script>
</body>
</html>
