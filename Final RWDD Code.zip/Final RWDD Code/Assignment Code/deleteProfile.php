<?php
include ('dbpage.php');
include ('session.php');
if (!isset($_SESSION['Role']) == 'A'){
    header('Location: loginPage.php');
    exit();
}
$ID = $_GET['ID'];

if (isset($_POST['btnDel'])) {
    $Name = $_POST['txtName'];
    $Age = $_POST['Age'];
    $Email = $_POST['txtEmail'];
    $Address = $_POST['txtAddress'];
    $Phone = $_POST['txtPhone'];
    $Role = $_POST['Role'];
    $deleteQuery = "DELETE * FROM vbdb WHERE ID='$ID'";
    if (mysqli_query($connection, $deleteQuery)) {
        echo '<br>Record deleted successfully';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="Shortcut Icon" href="Images/SmallLogo.png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box; /*This makes the div same size although one may have 50px padding and the other don't (Regardless of padding, border)*/
        }

        body {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: floralwhite;
        }

        /* Header styling */
        header {
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: bisque;
            padding: 10px 0;
            z-index: 1000; /*This makes so header is 1000 page infornt*/
        }

        nav {
            display: flex; /* example: https://www.w3schools.com/cssref/playdemo.php?filename=playcss_display&preval=flex*/
            justify-content: space-between; /* example: https://www.w3schools.com/cssref/playdemo.php?filename=playcss_display&preval=flex*/
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .logo img{
            width: 200px;
            height: auto;          
        }

        .nav-links {
            list-style: none;
            display: flex;
            position: relative;
        }

        .nav-links li {
            margin-left: 20px;
            position: relative;
        }

        .nav-links a {
            font-weight: bold;
            color: black;
            text-decoration: none;
            font-size: 10pt;
            padding: 8px 15px;
            transition: all 1s ease;
        }

        .nav-links a:hover {
            color: darkkhaki;          
        }

        .dropdown {
            position: absolute;
            top: calc(100% + 5px);
            left: 0;
            display: none;
            background-color: bisque;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            list-style: none;
            padding: 0;
            width: 120px;
            margin: 0;
            z-index: 1000
        }

        .dropdown li {
            margin: 0;
        }

        .dropdown a {
            display: block;
            padding: 5px 10px;
            font-size: 9pt;
            text-align: left;
            transition: all 1s ease;
        }

        .dropdown a:hover {
            color: darkkhaki;
        }

        /* Show the dropdown when hovering on desktop */
        .nav-links li:hover .dropdown {
            display: block;
        }

        .cta {
            display: flex;
            align-items: center;
        }

        .cta img {
            width: 17px;           
            margin-right: 2px;
        }
        
        .cta .cartbtn {
            background-color: bisque;
            padding: 8px 15px;
            color: #fff;
            display: flex;
            margin-right: 4px;
            align-items: center;
        }

        .cta .shopbtn {
            background-color: orangered;
            padding: 8px 15px;
            color: black;
            font-weight: bold;
            font-size: 9pt;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 1s ease;
        }

        .session {
            margin-bottom: 20px;
            background-color: lemonchiffon;
            color: black;
            padding: 14px 28px;
            font-size: 12pt;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }

        .session a {
            font-weight: bold;
            color: black;
            text-decoration: none;
            font-size: 10pt;
            padding: 8px 15px;
            transition: all 1s ease;
        }

        main{
            padding-top: 100px;
            padding-bottom: 20px;
            padding: 20px;
        }
       
        /* Main Section */
        .welcome {
            background-image: url(Images/hpCoverPic.png);
            background-size: cover;
            background-position: center;
            color: black;
            text-align: center;
            padding: 100px 20px;
        }

        .welcome-content h1 {
            font-size: 32pt;
            margin-bottom: 10px;
            color: saddlebrown;
        }

        .welcome-content p{
            font-size: 24pt;
            font-weight: bold;
            color: lightsalmon;
        }    

        /* Our Goal Section */
        .ourgoal {
            text-align: center;
            padding: 50px 20px;
            background-color: lavenderblush;
        }

        .ourgoal h2{
            font-size: 26pt;
            color: dimgray;
            margin-bottom: 20px;
        }

        .ourgoal p{
            font-size: 14pt;
            font-weight: bold;
            color: mediumseagreen;
        }

        .whyus{
            text-align: center;
            padding: 50px 20px;
            background-color: floralwhite;
        }

        .whyus h2{
            font-size: 26pt;
            color: slategray;
            margin-bottom: 20px;
        }

        .whyus p{
            font-size: 13pt;
            font-weight: bold;
            color: #0096FF;
        }

        /* Coaches Section */
        .coaches {
            background-color: antiquewhite;
            padding: 50px 20px;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .coaches h2 {
            font-size: 26pt;
            color: slategray;
        }

        .coach-card {
            background-color: white;
            border: 1px solid black;
            padding: 20px;
            border-radius: 8px;
            margin: 10px;
            width: 250px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            text-align: center;
        }

        .coach-card img {
            width: 200px;
            height: 200px;
            object-fit: cover;
            margin-bottom: 15px;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 140px);
            flex-direction: column;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-top: 500px;
            margin-bottom: 10px;
        }

        .container h2 {
            font: bold;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        /* Form Styles */
        form {
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="int"],
        input[type="email"],
        input[type="text"],
        input[type="text"],
        input[type="text"],
        select {
            align-items: center;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: bisque;
            color: black;
            padding: 10px 15px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
        
        footer{
            background-color: #333;
            color: white;
            text-align: left;
            padding: 16px;
            margin-top: 20px;
            clear: both;
        }

        footer p{
            font-size: 20pt;
        }
        /* Responsive styling */
        /* Responsive Layout: Desktop and Larger Devices */
        @media (min-width: 1024px) {
            nav {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                padding: 0 15px;
            }

            .logo img {
                width: 180px; 
            }

            .nav-links li {
                margin-left: 15px; 
            }

            .nav-links a {
                font-size: 9pt; 
                padding: 8px 12px;
            }

            .cta .cartbtn {
                padding: 6px 12px;
                font-size: 9pt;
            }
        }

        /* Tablet Layout */
        @media (min-width: 768px) and (max-width: 1023px) {
            nav {
                flex-direction: column;
                align-items: flex-start;
                padding: 0 10px;
            }

            .nav-links {
                flex-direction: column;
                width: 100%;
                margin-top: 10px;
            }

            .nav-links li {
                margin: 10px 0;
            }

            .nav-links a {
                width: 100%;
                padding: 10px 0;
                text-align: center;
                font-size: 12pt;
            }

            .cta {
                margin-top: 10px;
            }
            body{
                padding-top: 360px;
            }
        }

         /*Mobile Layout*/
        @media (max-width: 767px) {
            .logo img {
                width: 150px;
            }
            
            nav {
                flex-direction: column;
                align-items: flex-start;
                padding: 10px;
            }

            .nav-links { 
                flex-direction: column;
                width: 100%;
            }

            .nav-links li {
                margin: 10px 0;
            }

            .nav-links a {
                width: 100%;
                padding: 10px;
                text-align: center;
                font-size: 12pt;
            }

            .cta {
                margin-top: 10px;
            }

            .cta .cartbtn {
                font-size: 14px;
                padding: 10px;
            }

            body{
                padding-top: 425px;
            }
        } 
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <a href="Homepage.html">
                    <img src="Images/Logo.png" alt="Logo Icon">
                </a>
            </div>

            <ul class="nav-links">
                <li><a href="Homepage.html">Homepage</a></li>
                <li>
                    <a href="AboutUs.html">About Us</a>
                    <ul class="dropdown">
                        <li><a href="CoachLC.html">Coach Chrollo</a></li>
                        <li><a href="CoachJS.html">Coach Smith</a></li>
                    </ul>
                </li>
                <li><a href="ContactUs.html">Contact Us</a></li>
                <li><a href="Program.html">Program</a></li>
                <li><a href="Calendar.html">Calendar</a></li>
                <li><a href="FAQ.html">FAQ</a></li>
                <li><a href="Testimonials.html">Testimonials</a></li>
            </ul>

            <div class="cta">
                <a href="shop.html" class="shopbtn">Shop</a>
                <a href="viewcart.html" class="cartbtn"><img src="Images/Cart.png" alt="Cart Icon"></a>
            </div>

            <div class="session">               
                    <a href="adminlist.php">EditUser</a> | 
                    <a href="logoutPage.php">Logout</a>
            </div>
        </nav>
    </header>
</body>
<body>
    <section>
        <div class="container">
            <h2>Edit User</h2>
            <?php
            $query = "SELECT * FROM vbdb WHERE ID='$ID'";
            $results = mysqli_query($connection, $query);
            if (mysqli_num_rows($results) == 1) 
                $row = mysqli_fetch_assoc($results);
            ?>
                <form action="" method="post">
                    Name : <input type="text" name="txtName"
                        value="<?php echo $row['Name']; ?>"> <br>
                    Age : <input type="int" name="Age"
                        value="<?php echo $row['Age']; ?>"> <br>
                    Email : <input type="email" name="txtEmail"
                        value="<?php echo $row['Email']; ?>"> <br>
                    Address : <input type="text" name="txtAddress"
                        value="<?php echo $row['Address']; ?>"><br>
                    Phone : <input type="text" name="txtPhone"
                        value="<?php echo $row['Phone']; ?>"><br>
                    Role: <input type="text" name="Role"
                        value="<?php echo $row['Role']; ?>"><br>
                    <input type="submit" value="Delete" name="btnDel">
                </form>
        </div>
    </section>

</body>
<body>

    <footer>
            <p>&copy; Tobe Volleyball Club</p>
            <div id="Footer"></div>
                <h3>CONTACT INFO</h3>
                <label>
                <table>
                    <tr>
                        <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4vtphMtxRWfK6nO2CIbGfSETyEs79Dr6oPw&s" alt="Gmail Picture" 
                            height="30" width="45"></td>
                        <td>Email Address:</td>
                        <td><a href="mailto:TobeVC@gmail.com" target="_blank">TobeVC@gmail.com</a></td>
                    </tr>
                    <tr>
                        <td><img src="https://seeklogo.com/images/W/whatsapp-logo-0DBD89C8E2-seeklogo.com.png" alt="Whatsapp Logo"
                            height="30" width="45"></td>
                        <td>Phone Number:</td>
                        <td>
                            <a href="https://wa.me/+60128894667" target="_blank"></a>
                            <a href="tel:+60128894667" target="_blank">+60128894667</a>
                        </td>
                    </tr>
                </table>
                </label>
            </div>
        </footer>
</body>
</html>